#include <stdio.h>
#include "distance.h"

int main() {
  double ret = get_distance(0, -3, 4, 0);
  printf("return value : %lf \n", ret);
  return 0;
}
